#import <UIKit/UIKit.h>

//! Project version number for AirlineAccelerator.
FOUNDATION_EXPORT double AirlineAcceleratorVersionNumber;

//! Project version string for AirlineAccelerator.
FOUNDATION_EXPORT const unsigned char AirlineAcceleratorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AirlineAccelerator/PublicHeader.h>


